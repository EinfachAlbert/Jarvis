import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(__dirname));

function getClient() {
  if (!process.env.OPENAI_API_KEY) return null;
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

const modeSettings = {
  normal: "Antworte schnell und direkt.",
  plus: "Nimm dir mehr Zeit für eine hochwertige, strukturierte Antwort.",
  lux: "Liefere die bestmögliche Antwort mit besonders sorgfältigem Reasoning und hochwertigem Code."
};

app.post("/api/chat", async (req, res) => {
  try {
    const client = getClient();
    if (!client) {
      return res.status(500).json({
        error: "OPENAI_API_KEY ist auf dem Server noch nicht eingerichtet."
      });
    }

    const {
      message,
      history = [],
      mode = "normal",
      web = true,
      code = false
    } = req.body || {};

    if (!message?.trim()) {
      return res.status(400).json({ error: "Nachricht fehlt." });
    }

    const safeHistory = Array.isArray(history)
      ? history
          .filter(x => x && ["user", "assistant"].includes(x.role))
          .filter(x => typeof x.content === "string")
          .slice(-20)
      : [];

    const instructions = [
      "Du bist JARVIS, ein moderner persönlicher KI-Assistent.",
      "Antworte standardmäßig auf Deutsch.",
      "Verwende keine Emojis.",
      "Sei direkt, hilfreich und ehrlich.",
      modeSettings[mode] || modeSettings.normal,
      code
        ? "Der Nutzer möchte echten Code. Liefere vollständigen, direkt nutzbaren Code und keine erfundenen Testergebnisse."
        : ""
    ].filter(Boolean).join(" ");

    const input = [
      ...safeHistory,
      { role: "user", content: message }
    ];

    const request = {
      model: process.env.OPENAI_MODEL,
      instructions,
      input
    };

    if (web) {
      request.tools = [{ type: "web_search" }];
    }

    const response = await client.responses.create(request);

    res.json({
      content: response.output_text || "Keine Antwort erhalten."
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: error?.message || "Unbekannter Serverfehler."
    });
  }
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "JARVIS" });
});

app.listen(PORT, () => {
  console.log(`JARVIS läuft auf http://localhost:${PORT}`);
});