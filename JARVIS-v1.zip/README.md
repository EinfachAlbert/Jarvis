# JARVIS

Modern AI assistant by EinfachAlbert.

## Enthalten
- Chat
- Normal / Plus / Lux
- echter Server-Backend-Aufbau
- optional Websuche
- Code Studio
- mehrere Programmiersprachen
- Mikrofon-Eingabe
- Sprachausgabe
- Einstellungen
- lokale Chat-Historie
- sichere API-Key-Struktur

## Start

1. Node.js installieren.
2. `npm install`
3. `.env.example` zu `.env` kopieren.
4. `OPENAI_API_KEY` und `OPENAI_MODEL` eintragen.
5. `npm start`
6. `http://localhost:3000` öffnen.

Den API-Key niemals in `app.js` oder `index.html` eintragen.
