const $=s=>document.querySelector(s);
const state={
 mode:localStorage.getItem("jarvis-mode")||"normal",
 messages:JSON.parse(localStorage.getItem("jarvis-messages")||"[]"),
 voice:true,web:true,save:true
};
const labels={normal:["Normal","Schnell"],plus:["Plus","Mehr Qualität"],lux:["Lux","Maximale Qualität"]};
const messages=$("#messages");

function render(){
 messages.innerHTML="";
 $("#welcome").classList.toggle("hidden",state.messages.length>0);
 state.messages.forEach(m=>{
   const row=document.createElement("div");row.className="message "+m.role;
   const avatar=document.createElement("div");avatar.className="avatar";avatar.textContent=m.role==="user"?"DU":"J";
   const content=document.createElement("div");content.className="content";content.textContent=m.content;
   row.append(avatar,content);messages.append(row);
 });
}
function save(){if(state.save)localStorage.setItem("jarvis-messages",JSON.stringify(state.messages))}
function setMode(m){
 state.mode=m;localStorage.setItem("jarvis-mode",m);
 $("#modeName").textContent=labels[m][0];$("#modeDescription").textContent=labels[m][1];
 $("#modeMenu").classList.add("hidden");
}
function view(name){
 document.querySelectorAll(".view").forEach(x=>x.classList.add("hidden"));
 $("#"+name+"View").classList.remove("hidden");
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.view===name));
 $("#sidebar").classList.remove("open");
}
setMode(state.mode);render();

$("#modeButton").onclick=()=>$("#modeMenu").classList.toggle("hidden");
document.querySelectorAll("[data-mode]").forEach(x=>x.onclick=()=>setMode(x.dataset.mode));
document.querySelectorAll(".nav").forEach(x=>x.onclick=()=>view(x.dataset.view));
$("#menu").onclick=()=>$("#sidebar").classList.toggle("open");
$("#newChat").onclick=()=>{state.messages=[];save();render();view("chat")};
$("#settingsBtn")?.addEventListener("click",()=>view("settings"));
document.querySelectorAll("[data-prompt]").forEach(x=>x.onclick=()=>{$("#prompt").value=x.dataset.prompt;$("#prompt").focus()});

$("#prompt").addEventListener("input",e=>{e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,180)+"px"});
$("#prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
$("#send").onclick=send;

async function send(){
 const input=$("#prompt"),text=input.value.trim();if(!text)return;
 state.messages.push({role:"user",content:text});input.value="";input.style.height="auto";render();
 $("#status").textContent="JARVIS denkt...";
 const answer={role:"assistant",content:""};state.messages.push(answer);render();
 try{
   const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},
     body:JSON.stringify({message:text,history:state.messages.slice(0,-1).slice(-20),mode:state.mode,web:state.web})});
   const d=await r.json();if(!r.ok)throw Error(d.error||"Serverfehler");
   answer.content=d.content||"Keine Antwort erhalten.";
   if(state.voice)speak(answer.content);
 }catch(e){answer.content="Fehler: "+e.message}
 save();render();$("#status").textContent="Bereit";
}

function speak(text){
 if(!("speechSynthesis" in window))return;
 speechSynthesis.cancel();
 const u=new SpeechSynthesisUtterance(text.replace(/```[\s\S]*?```/g,"Code wurde erstellt."));
 u.lang="de-DE";u.rate=state.mode==="lux"?.98:1.02;
 const voices=speechSynthesis.getVoices();
 const v=voices.find(x=>/male|david|mark|thomas|hans|stefan/i.test(x.name))||voices.find(x=>x.lang.startsWith("de"));
 if(v)u.voice=v;speechSynthesis.speak(u);
}
$("#voiceToggle").onclick=()=>{state.voice=!state.voice;$("#voiceToggle").textContent=state.voice?"Voice an":"Voice aus";$("#speech").checked=state.voice};
$("#speech").onchange=e=>state.voice=e.target.checked;
$("#web").onchange=e=>state.web=e.target.checked;
$("#save").onchange=e=>{state.save=e.target.checked;if(!state.save)localStorage.removeItem("jarvis-messages")};
$("#clear").onclick=()=>{localStorage.removeItem("jarvis-messages");state.messages=[];render()};

function setupMic(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){$("#micStatus").textContent="Spracherkennung nicht verfügbar";return}
 const r=new SR();r.lang="de-DE";r.interimResults=true;r.continuous=false;
 r.onstart=()=>{$("#mic").textContent="Stop";$("#micStatus").textContent="Ich höre zu..."};
 r.onresult=e=>{let t="";for(const x of e.results)t+=x[0].transcript;$("#prompt").value=t;$("#prompt").dispatchEvent(new Event("input"))};
 r.onerror=e=>$("#micStatus").textContent="Mikrofon: "+e.error;
 r.onend=()=>{$("#mic").textContent="Mic";$("#micStatus").textContent="Mikrofon bereit";if($("#prompt").value.trim())send()};
 $("#mic").onclick=()=>{try{r.start()}catch{}};
}
setupMic();

$("#generate").onclick=async()=>{
 const task=$("#codePrompt").value.trim();if(!task)return;
 const lang=$("#language").value,target=$("#target").value.trim();
 $("#output").textContent="Generiere...";
 try{
   const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({message:"Erstelle vollständigen, echten, direkt nutzbaren Code. Aufgabe: "+task+" Sprache: "+lang+" Ziel/Version: "+target+". Gib nur einen Codeblock aus.",history:[],mode:state.mode,web:false,code:true})});
   const d=await r.json();if(!r.ok)throw Error(d.error||"Fehler");
   const match=d.content.match(/```(?:[\w#+.-]+)?\s*([\s\S]*?)```/);
   $("#output").textContent=match?match[1].trim():d.content;
   $("#codeTitle").textContent=lang+(target?" · "+target:"");
 }catch(e){$("#output").textContent="Fehler: "+e.message}
};
$("#copy").onclick=async()=>{await navigator.clipboard.writeText($("#output").textContent);$("#copy").textContent="Kopiert";setTimeout(()=>$("#copy").textContent="Kopieren",1200)};
